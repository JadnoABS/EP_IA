# TODO

- [ ] Backpropagation
  - [ ] Calculate error
  - [ ] Updates weights


- [ ] Camada de entrada da rede neural.
- [ ] o Camada de saída da rede neural.
- [ ] o Camada escondida da rede neural.
- [ ] o Função (ou funções) de ativação dos neurônios.
- [ ] o Taxa de aprendizado.
- [ ] o Termos de regularização ou procedimentos de otimização adaptativos 
  (se  estiver sendo usado).
- [ ] o Loop do procedimento de treinamento.
- [ ] o Critério de parada do treinamento.
- [ ] o Conjunto de pesos sinápticos em cada camada.
- [ ] o Atualização dos pesos sinápticos em cada camada.
- [ ] o Procedimentos de cálculo de erro na camada de saída (para cada 
  neurônio e para a rede neural).
- [ ] o Procedimento de cálculo de informação de erro para a retropropagação.
- [ ] o Procedimento de cálculo de contribuição de erro na camada escondida.
- [ ] o Procedimento de cálculo da resposta da rede em termos de 
  reconhecimento do caractere.
- [ ] o Procedimento de cálculo da matriz de confusão.

