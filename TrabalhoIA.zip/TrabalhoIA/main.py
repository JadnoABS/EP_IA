import numpy as np
import pandas as pd

from mlp.neural_network import NeuralNetwork

if __name__ == "__main__":
    print("Começando...")

    train = pd.read_csv("train.csv").values
    test = pd.read_csv("test.csv").values

    X_train = np.array([x_t[:63] for x_t in train])
    Y_train = np.array([y_t[63:] for y_t in train])
    X_test = np.array([x_t[:63] for x_t in test])
    Y_test = np.array([y_t[63:] for y_t in test])

    NN = NeuralNetwork(X_train, Y_train, X_test, Y_test, 5, 10)

    NN.test(X_test, Y_test)

