from math import exp
from random import random
import numpy as np


class BaseNeuron:
    # o ultimo peso faz referencia ao bias
    weights: np.core.multiarray

    output = 0
    error = 0
    delta = 0
    after_activation = 0

    def __init__(self, next_layer_size):
        self.weights = np.array([random() - 0.5 for i in range(next_layer_size
                                                              + 1 )])

    def receive(self, signals: np.core.multiarray) -> float:
        result = np.matrix.dot(signals, self.weights[:-1].T)
        result += self.weights[-1]
        return result

    def activate(self, signals: list) -> float:
        self.after_activation = self.receive(signals)
        output = 1 if self.after_activation else 0
        self.output = output

        return output

    def derivate_activation(self):
        return 1 if self.after_activation else 0

    def calculate_delta(self, err):
        pass

    def update_weight(self, rate, signals):
        pass

    def __repr__(self) -> str:
        return f"{{ weights:{self.weights} output:{self.output} error" \
               f":{self.error} }}"


class HiddenNeuron(BaseNeuron):
    def calculate_delta(self, deltas):
        next_layer_err = 0
        for index in range(len(deltas)):
            next_layer_err += deltas[index] * self.weights[index]

        self.delta = next_layer_err * self.derivate_activation()

    def update_weight(self, rate, signals):
        for index, w in enumerate(self.weights):
            self.weights[index] += rate * self.delta * signals[index]


class OutNeuron(BaseNeuron):
    def calculate_delta(self, error):
        self.delta = error * self.derivate_activation()

    def update_weight(self, rate, signals):
        for index, w in enumerate(self.weights):
            self.weights[index] += rate * self.delta * signals[index]
