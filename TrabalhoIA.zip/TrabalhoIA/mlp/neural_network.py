import numpy as np

from mlp.neurons import HiddenNeuron, OutNeuron


class NeuralNetwork:
    layers: list = []
    rate = 0.1

    def __init__(self, x_train, y_train, x_test, y_test, n_layers, rate):
        self.construct_layers(x_train.shape[1], y_train.shape[1], n_layers)
        self.rate = rate

        self.train(x_train, y_train, x_test, y_test)

    def construct_layers(self, n_inputs, n_outputs, n_layers):
        self.layers = [[HiddenNeuron(n_inputs) for _ in range(n_inputs)] for
                       _ in range(n_layers)]

        self.layers.append([OutNeuron(n_inputs) for _ in range(n_outputs)])

    def propagate(self, inputs: list):
        for index, layer in enumerate(self.layers):
            next_input = []
            input_arr = np.array(inputs)
            for neuron in layer:
                output = neuron.activate(input_arr)
                next_input.append(output)
                inputs = next_input
            max_index = np.array(inputs).argmax()
            for n_index, neuron in enumerate(layer):
                if n_index == max_index:
                    neuron.output = 1
                    inputs[n_index] = 1
                else:
                    neuron.output = 0
                    inputs[n_index] = 0

        return inputs

    def calculate_initial_error(_, result, expected):
        err = 0
        for index, x in enumerate(expected):
            err += 0.5*(x - result[index])**2

        return err

    def calculate_errors(self, result, expected, input_array):
        initial_err = self.calculate_initial_error(result, expected)
        ik = self.get_outputs_from_layer(-2)
        for outNeuron in self.layers[-1]:
            outNeuron.calculate_delta(initial_err)
            outNeuron.update_weight(self.rate, ik)

        for index in range(len(self.layers) - 2, -1, -1):
            deltas = self.get_deltas_from_layer(index+1)

            outputs = []

            if index == 0:
                outputs = input_array.tolist()
                outputs.append(1)
            else:
                outputs = self.get_outputs_from_layer(index - 1)

            for hiddenNeuron in self.layers[index]:
                hiddenNeuron.calculate_delta(deltas)
                try:
                    hiddenNeuron.update_weight(self.rate, outputs)
                except Exception as err:
                    print(index, len(outputs))
                    raise Exception(err)

    def get_outputs_from_layer(self, index):
        outputs = [x.output for x in self.layers[index]]
        outputs.append(1)
        return outputs

    def get_deltas_from_layer(self, index):
        return [x.delta for x in self.layers[index]]

    def train(self, input_array, expected, x_test, y_test):
        epoch = 0
        while epoch < 100:
            for index in range(len(input_array)):
                result = self.propagate(input_array[index])
                self.calculate_errors(result, expected[index], input_array[index])
            epoch += 1
            if epoch % 25 == 0:
                print("Epoch: ", epoch)
                self.test(x_test, y_test)

    def test(self, x_test, y_test):
        err = 0
        for index, received in enumerate(x_test):
            results = self.propagate(x_test[index])
            result = np.array(results).argmax()
            expected = np.array(y_test[index]).argmax()
            # print(f"Input {index}: {result} -- "
            #       f"{expected}")
            if result != expected:
                err += 1

        print("Number of errors: ", err)


